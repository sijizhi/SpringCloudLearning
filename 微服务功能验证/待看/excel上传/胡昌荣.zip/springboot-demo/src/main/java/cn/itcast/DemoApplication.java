package cn.itcast;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

/**
 * @author: HuYi.Zhang
 * @create: 2018-07-11 09:04
 **/
@SpringBootApplication
@MapperScan("cn.itcast.mapper")
public class DemoApplication {
    public static void main(String[] args) {
        // 启动springboot
        SpringApplication.run(DemoApplication.class, args);
    }
}
