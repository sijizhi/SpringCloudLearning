package cn.itcast.controller;

import cn.itcast.pojo.User;
import cn.itcast.service.UserService;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.List;

/**
 * @author: HuYi.Zhang
 * @create: 2018-07-11 09:06
 **/
@RestController
public class HelloController {
//
//    @Autowired
//    private DataSource dataSource;

    @Autowired
    private UserService userService;

    @GetMapping("hello")
    public String hello() {
        System.out.println("handler 执行了");
        return "hello";
    }

        @PostMapping("import")
        public boolean addUser(HttpServletRequest request) {
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;

            MultipartFile file = multipartRequest.getFile("filename");
            boolean a = false;
            String fileName = file.getOriginalFilename();
            try {
                a = userService.batchImport(fileName, file);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return  a;
        }



}
