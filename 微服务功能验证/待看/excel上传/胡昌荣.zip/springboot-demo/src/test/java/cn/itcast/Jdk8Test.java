package cn.itcast;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author: HuYi.Zhang
 * @create: 2018-07-11 12:18
 **/
public class Jdk8Test {

    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(10, 5, 25, -15, 20);

        Collections.sort(list, (i1, i2) -> i1 - i2);

//        for (Integer integer : list) {
//            System.out.println("integer = " + integer);
//        }
        list.forEach( i -> System.out.println("i = " + i));

        Runnable task = () -> System.out.println("running");

        new Thread(task).start();

        int num = 1;

        Runnable t = () -> {
            System.out.println(num);
        };
    }
}
